import React, { useState, useEffect, useRef } from 'react';
import Bridge from './components/bridge'; 

function App() {
  const [status, setStatus] = useState("System Ready");
  const [displayContent, setDisplayContent] = useState("");
  const hiddenInputRef = useRef(null);

  const speakText = (text) => {
    if (!text) return;
    
    window.speechSynthesis.cancel();
    window.speechSynthesis.resume(); 

    setTimeout(() => {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.onstart = () => setStatus("Reading aloud...");
        utterance.onend = () => setStatus("System Ready");
        
        window.speechSynthesis.speak(utterance);
        
        const keepAlive = setInterval(() => {
            if (!window.speechSynthesis.speaking) clearInterval(keepAlive);
            else window.speechSynthesis.resume();
        }, 1000);
    }, 150);
  };

  useEffect(() => {
    if (hiddenInputRef.current) {
      hiddenInputRef.current.focus();
    }

    const handleKeyDown = (event) => {
      // Shortcut: Ctrl + Shift
      if (event.ctrlKey && event.shiftKey) {
        event.preventDefault(); 
        // 📍 Phonetic fix: We write it as 'Innovators' so it sounds natural
        speakText("Innovators AI voice system enabled.");
      }

      // Shortcut: Escape
      if (event.key === "Escape") {
        window.speechSynthesis.cancel();
        setStatus("Stopped");
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const getStatusColor = () => {
    if (status.includes("Reading")) return "#22d3ee"; 
    if (status.includes("Stopped")) return "#f43f5e"; 
    return "#818cf8"; 
  };

  return (
    <div style={styles.container}>
      <input ref={hiddenInputRef} style={{ position: 'absolute', opacity: 0 }} readOnly />

      <div style={styles.glassCard}>
        {/* 📍 Visual name remains INNOV80RS */}
        <h1 style={styles.title}>INNOV80RS <span style={{fontWeight: '300', color: '#818cf8'}}>AI</span></h1>
        
        <p style={{ ...styles.status, color: getStatusColor() }}>
          ● {status}
        </p>

        <button 
          onClick={() => speakText("Innovators AI voice system enabled.")} 
          style={styles.enableBtn}
        >
          ENABLE VOICE SYSTEM
        </button>
        
        <p style={styles.shortcutHint}>Press <b>Ctrl + Shift</b> to activate | <b>Esc</b> to stop</p>

        <div style={styles.bridgeContainer}>
          <Bridge 
            onSummaryReceived={(text) => setDisplayContent(text)} 
            onReadCommand={(textToRead) => speakText(textToRead)}
          />
        </div>

        <div style={styles.outputBox}>
          <h2 style={styles.outputLabel}>OUTPUT LOG</h2>
          <div style={styles.textContent}>
            {displayContent || "System standby. Say 'Open file' to initiate..."}
          </div>
        </div>
        
        <button onClick={() => { window.speechSynthesis.cancel(); setStatus("Stopped"); }} style={styles.stopBtn}>
          TERMINATE VOICE (ESC)
        </button>
      </div>
    </div>
  );
}

const styles = {
  container: {
    backgroundColor: '#05060b',
    backgroundImage: 'radial-gradient(circle at 50% 50%, #0f111a 0%, #05060b 100%)',
    minHeight: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    fontFamily: "'Inter', system-ui, sans-serif",
    padding: '20px',
  },
  glassCard: {
    background: 'rgba(15, 23, 42, 0.6)',
    backdropFilter: 'blur(16px)',
    borderRadius: '32px',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    width: '100%',
    maxWidth: '700px',
    padding: '60px 40px',
    textAlign: 'center',
    boxShadow: '0 40px 100px rgba(0,0,0,0.6)',
  },
  title: {
    color: '#fff',
    fontSize: '3rem',
    letterSpacing: '4px',
    margin: '0 0 10px 0',
  },
  status: {
    fontSize: '0.85rem',
    textTransform: 'uppercase',
    letterSpacing: '3px',
    marginBottom: '40px',
    fontWeight: '600',
  },
  enableBtn: {
    backgroundColor: '#6366f1',
    color: '#fff',
    border: 'none',
    padding: '16px 40px',
    borderRadius: '12px',
    fontWeight: '700',
    cursor: 'pointer',
  },
  shortcutHint: {
    color: '#475569',
    fontSize: '0.75rem',
    marginTop: '20px',
  },
  bridgeContainer: {
    margin: '45px 0',
  },
  outputBox: {
    background: 'rgba(2, 6, 23, 0.7)',
    borderRadius: '20px',
    padding: '30px',
    borderLeft: '4px solid #6366f1',
    textAlign: 'left',
    minHeight: '180px',
    marginBottom: '35px',
  },
  outputLabel: {
    fontSize: '0.65rem',
    color: '#818cf8',
    margin: '0 0 15px 0',
    fontWeight: 'bold',
  },
  textContent: {
    color: '#cbd5e1',
    fontSize: '1.15rem',
    lineHeight: '1.7',
  },
  stopBtn: {
    backgroundColor: 'transparent',
    color: '#f43f5e',
    border: '1px solid rgba(244, 63, 94, 0.3)',
    padding: '10px 28px',
    borderRadius: '12px',
    cursor: 'pointer',
    fontSize: '0.75rem',
    fontWeight: 'bold',
    textTransform: 'uppercase',
  }
};

export default App;