import React from 'react';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';

const VoiceHandler = () => {
  // We only pull what we absolutely need: the live transcript and the listening status
  const {
    transcript,
    listening,
    browserSupportsSpeechRecognition
  } = useSpeechRecognition();

  if (!browserSupportsSpeechRecognition) {
    return <p>Your browser does not support speech recognition. Please use Chrome.</p>;
  }

  return (
    <div style={{ 
      padding: '20px', 
      backgroundColor: '#333', 
      borderRadius: '15px', 
      border: '2px solid #FFD700',
      maxWidth: '600px',
      margin: '0 auto'
    }}>
      <h2 style={{ color: 'white' }}>
        Ear Module: {listening ? '🔴 Listening...' : '🛑 Mic Off'}
      </h2>
      
      <div style={{ marginBottom: '20px' }}>
        <button 
          onClick={() => SpeechRecognition.startListening({ continuous: true })}
          style={{ padding: '10px 20px', margin: '5px', cursor: 'pointer', fontWeight: 'bold', backgroundColor: 'white', color: 'black' }}
        >
          Start Listening
        </button>
        <button 
          onClick={SpeechRecognition.stopListening}
          style={{ padding: '10px 20px', margin: '5px', cursor: 'pointer', backgroundColor: 'white', color: 'black' }}
        >
          Stop Listening
        </button>
      </div>

      {/* The Black Box: It strictly displays what you say. */}
      <div style={{ 
        backgroundColor: '#000', 
        padding: '15px', 
        color: '#00FF00', 
        textAlign: 'left',
        minHeight: '100px',
        fontFamily: 'monospace',
        marginBottom: '15px'
      }}>
        <strong>Live Transcript:</strong> <br/> <br/>
        {transcript}
      </div>
    </div>
  );
};

export default VoiceHandler;