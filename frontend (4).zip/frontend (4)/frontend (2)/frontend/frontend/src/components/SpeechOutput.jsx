import React, { useState } from 'react';

const SpeechOutput = ({ textToRead }) => {
  const [rate, setRate] = useState(1); 

  const handleSpeak = () => {
    window.speechSynthesis.cancel(); 
    const utterance = new SpeechSynthesisUtterance(textToRead);
    utterance.rate = rate;
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div style={{ backgroundColor: '#111', color: '#FF0', padding: '20px', borderRadius: '15px', border: '3px solid #FF0', marginTop: '20px' }}>
      <h2>🔊 Voice Output Module</h2>
      <div style={{ marginBottom: '15px' }}>
        <label>Reading Speed: {rate}x</label>
        <input type="range" min="0.5" max="2" step="0.1" value={rate} onChange={(e) => setRate(e.target.value)} style={{ width: '100%' }} />
      </div>
      <button onClick={handleSpeak} style={{ padding: '15px', width: '100%', backgroundColor: '#FF0', color: '#000', fontWeight: 'bold', fontSize: '20px', cursor: 'pointer' }}>
        PLAY RESPONSE ALOUD
      </button>
    </div>
  );
};

export default SpeechOutput;
