import React, { useEffect, useRef } from 'react';
import axios from 'axios';

const Bridge = ({ onSummaryReceived, onReadCommand }) => {
  const recognitionRef = useRef(null);
  const fullTextRef = useRef(""); 

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = async (event) => {
        const transcript = event.results[event.results.length - 1][0].transcript.toLowerCase().trim();
        
        // 📍 Internal log updated to new branding
        console.log("INNOV80RS AI Heard:", transcript);

        // 🔴 STOP: Kills all active speech immediately
        if (transcript.includes("stop")) {
          window.speechSynthesis.cancel();
          onSummaryReceived("Voice playback stopped.");
          return;
        }

        // 🟢 OPEN: Finds the filename and loads it
        if (transcript.startsWith("open") || transcript.startsWith("load")) {
          const words = transcript.split(" ");
          const filename = words[words.length - 1] + ".pdf";
          handleVoiceLoad(filename);
        }

        // 🟡 SUMMARIZE: Gets summary from Python and triggers voice
        if (transcript.includes("summarize")) {
          if (fullTextRef.current) handleSummarize();
          else onReadCommand("Please load a document first.");
        }

        // 🔵 START: Reads the full loaded text
        if (transcript.includes("start") || transcript.includes("read")) {
          if (fullTextRef.current) {
            onReadCommand(fullTextRef.current);
          } else {
            onReadCommand("No document is loaded.");
          }
        }
      };

      recognitionRef.current.onend = () => recognitionRef.current.start();
      recognitionRef.current.start();
    }
  }, [onReadCommand, onSummaryReceived]);

  const handleVoiceLoad = async (filename) => {
    onSummaryReceived(`Loading ${filename}...`);
    try {
      const res = await axios.post('http://127.0.0.1:5000/read-sample', { filename });
      fullTextRef.current = res.data.fullText;
      onSummaryReceived(`${filename} is ready.`);
      onReadCommand(`${filename.replace('.pdf', '')} is ready.`);
    } catch (err) {
      onSummaryReceived("File not found.");
      onReadCommand("File not found.");
    }
  };

  const handleSummarize = async () => {
    onSummaryReceived("Analyzing content...");
    try {
      const res = await axios.post('http://127.0.0.1:5000/summarize', { text: fullTextRef.current });
      const summaryResult = res.data.summary;
      onSummaryReceived(summaryResult);
      onReadCommand(summaryResult); 
    } catch (err) {
      onSummaryReceived("Summary failed.");
    }
  };

  return (
    <div style={styles.bridgeWrapper}>
      <p style={styles.activeLabel}>🎙️ INNOV80RS VOICE ENGINE ACTIVE</p>
      <p style={styles.commandHint}>"Open [file]", "Summarize", "Start", "Stop"</p>
    </div>
  );
};

const styles = {
  bridgeWrapper: {
    padding: '20px',
    border: '1px solid rgba(99, 102, 241, 0.3)', // Indigo border
    borderRadius: '20px',
    background: 'rgba(99, 102, 241, 0.05)', // Very subtle Indigo tint
    marginBottom: '20px',
    textAlign: 'center'
  },
  activeLabel: {
    color: '#818cf8', // Soft Indigo
    fontWeight: 'bold',
    margin: '0 0 5px 0',
    fontSize: '0.9rem',
    letterSpacing: '1px'
  },
  commandHint: {
    fontSize: '12px',
    color: '#475569', // Slate grey
    margin: 0,
    fontStyle: 'italic'
  }
};

export default Bridge;