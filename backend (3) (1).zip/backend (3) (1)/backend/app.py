import pdfplumber
import os
from flask import Flask, request, jsonify
from flask_cors import CORS
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lsa import LsaSummarizer
import nltk

nltk.download('punkt')

app = Flask(__name__)
CORS(app)

def summarize_logic(text):
    if not text or len(text.strip()) < 20:
        return "Document is too short to summarize."
    parser = PlaintextParser.from_string(text, Tokenizer("english"))
    summarizer = LsaSummarizer()
    summary = summarizer(parser.document, 3) 
    return " ".join([str(s) for s in summary])

@app.route('/read-sample', methods=['POST'])
def read_sample():
    data = request.json
    filename = data.get("filename", "")
    # Points to your backend/public folder
    file_path = os.path.join(os.getcwd(), 'public', filename)
    
    try:
        full_text = ""
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    full_text += text + " "
        return jsonify({"fullText": full_text})
    except Exception as e:
        return jsonify({"error": str(e)}), 404

@app.route('/summarize', methods=['POST'])
def summarize_api():
    data = request.json
    text_to_process = data.get("text", "")
    summary_result = summarize_logic(text_to_process)
    return jsonify({"summary": summary_result})

if __name__ == '__main__':
    app.run(port=5000, debug=True)